---# create database  for assessment

create database Assessment;

---# need use below statment to use table data

use Assessment;

---# create tables for assessment task 
---#Schema:
---# • students(student_id, name, country, registration_date)

CREATE TABLE students (
    student_id INT PRIMARY KEY,
    name VARCHAR(100),
    country VARCHAR(50),
    registration_date DATE
);

---# Data Values

INSERT INTO students (student_id, name, country, registration_date) VALUES
(1, 'Aisha Khan', 'India', '2025-01-10'),
(2, 'John Lee', 'USA', '2025-02-15'),
(3, 'Mei Chen', 'China', '2025-03-05'),
(4, 'Carlos Ruiz', 'Mexico', '2025-01-20'),
(5, 'Fatima Noor', 'UAE', '2025-04-01');

---# • courses(course_id, title, subject, level)

CREATE TABLE courses (
    course_id INT PRIMARY KEY,
    title VARCHAR(100),
    subject VARCHAR(50),
    level VARCHAR(50)
);

---# Data Values

INSERT INTO courses (course_id, title, subject, level) VALUES
(101, 'Python Basics', 'Programming', 'Beginner'),
(102, 'Data Analysis with R', 'Data Science', 'Intermediate'),
(103, 'Machine Learning Intro', 'Data Science', 'Advanced'),
(104, 'Web Development', 'Programming', 'Intermediate'),
(105, 'UX Design Principles', 'Design', 'Beginner');

---# • enrollments(student_id, course_id, enrollment_date)

CREATE TABLE enrollments (
	enrollment_id INT PRIMARY KEY,
    student_id INT,
    course_id INT,
    enrollment_date DATE,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

---# Data Values

INSERT INTO enrollments (enrollment_id, student_id, course_id, enrollment_date) VALUES
(1, 1, 101, '2025-01-12'),
(2, 1, 102, '2025-02-01'),
(3, 1, 103, '2025-03-10'),
(4, 2, 101, '2025-02-20'),
(5, 2, 104, '2025-03-01'),
(6, 3, 102, '2025-03-10'),
(7, 3, 103, '2025-03-15'),
(8, 3, 105, '2025-04-01'),
(9, 4, 101, '2025-01-25'),
(10, 4, 104, '2025-02-10'),
(11, 5, 105, '2025-04-05'),
(12, 5, 102, '2025-04-10'),
(13, 5, 103, '2025-04-15');

---# • progress(student_id, course_id, completed_percent, last_accessed)

CREATE TABLE progress (
	progress_id INT PRIMARY KEY,
    student_id INT,
    course_id INT,
    completed_percent DECIMAL(5,2),
    last_accessed DATE,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

---# Data Values

INSERT INTO progress (progress_id, student_id, course_id, completed_percent, last_accessed) VALUES
(1, 1, 101, 90.07, '2025-08-01'),
(2, 1, 102, 85.67, '2025-08-05'),
(3, 1, 103, 88.20, '2025-08-10'),
(4, 2, 101, 75.1, '2025-07-01'),
(5, 2, 104, 60.98, '2025-06-15'),
(6, 3, 102, 82.54, '2025-08-01'),
(7, 3, 103, 90.00, '2025-08-03'),
(8, 3, 105, 85.82, '2025-08-04'),
(9, 4, 101, 40.79, '2025-05-01'),
(10, 4, 104, 50.38, '2025-05-10'),
(11, 5, 105, 95.68, '2025-08-01'),
(12, 5, 102, 88.00, '2025-08-02'),
(13, 5, 103, 92.64, '2025-08-03');

---# Output for all data with tables 

select * from students;
select * from courses;
select * from enrollments;
select * from progress;

---#Assessment Tasks:
---# 1. Find the most popular course per subject (by enrollments).

SELECT subject
	,title course
	,enroll_count
FROM (
	SELECT c.subject
		,c.title
		,COUNT(e.student_id) AS enroll_count
		,RANK() OVER (
			PARTITION BY c.subject ORDER BY COUNT(e.student_id) DESC
			) AS rnk
	FROM courses c
	INNER JOIN enrollments e ON c.course_id = e.course_id
	GROUP BY c.subject
		,c.title
	) a
WHERE rnk = 1;

---# 2. List students who completed more than 80% in at least 3 courses.

SELECT s.name StudentName
FROM progress p
INNER JOIN students s ON p.student_id = s.student_id
WHERE completed_percent > 80
GROUP BY s.name
HAVING COUNT(course_id) >= 3;

---# 3. Calculate average course completion by level (e.g., beginner, intermediate).

SELECT c.LEVEL
	,ROUND(AVG(p.completed_percent), 2) AS avg_completion
FROM courses c
INNER JOIN progress p ON c.course_id = p.course_id
GROUP BY c.LEVEL;

---# 4. Identify students inactive for more than 60 days.

SELECT DISTINCT s.name Inactivestudents
FROM students s
INNER JOIN progress p ON s.student_id = p.student_id
WHERE DATEDIFF(CURDATE(), p.last_accessed) > 60;

---# 5. Determine the subject with the highest average completion rate.

SELECT subject
	,ROUND(AVG(completed_percent), 2) AS avg_completion
FROM courses c
INNER JOIN progress p ON c.course_id = p.course_id
GROUP BY subject
ORDER BY avg_completion DESC LIMIT 1;
